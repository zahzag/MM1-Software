import openpyxl
import sys

def add_value_to_excel(excel_file, column_num, value):
    # Load the workbook and select the sheet
    workbook = openpyxl.load_workbook(excel_file)
    sheet = workbook.active  # Or use workbook['SheetName'] for a specific sheet

    # Find the latest row
    latest_row = sheet.max_row  # This will give you the next empty row

    # Convert column number to letter
    column_letter = chr(64 + column_num)  # For column 1 = 'A', column 2 = 'B', etc.

    # Add the value to the specified column in the latest row
    sheet[f"{column_letter}{latest_row}"] = value

    # Save the workbook
    workbook.save(excel_file)
    print(f"Value '{value}' added to column {column_letter} at row {latest_row}")

# Command line arguments: python add_to_excel.py <excel_file> <column_number> <value>
if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python add_to_excel.py <excel_file> <column_number> <value>")
        sys.exit(1)

    excel_file = sys.argv[1]
    column_num = int(sys.argv[2])
    value = sys.argv[3]

    add_value_to_excel(excel_file, column_num, value)
