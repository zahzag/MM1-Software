#!/bin/bash

run_system() {

  cd build

  export CLASSPATH="../Server/Server/lib/*:."

  java Server.Server &

  taskset -c 8 java client.LoadGenerator

}

configure_cpu_performance() {
  cpu="$1"
  frequency="$2"
  governor="userspace"

  printf "setting cpu : $cpu to frequency : $frequency "Hz" , governor : $governor \ n"

  sudo cpupower --cpu "$cpu" frequency-set -g userspace -d $frequency -u $frequency
  cpupower --cpu $cpu frequency-info
}


compute_cpu_utilization() {
  local cpu="$1"
  local java_PID="$2"
  temp_file=$(mktemp)  # Create a temporary file for storing mpstat output

  # Start mpstat in the background and write to the temp file
  mpstat -P "$cpu" 1 > "$temp_file" &
  Mpstat_PID=$!

  echo "mpstat started with PID: $Mpstat_PID"

  # Wait for the Java process to finish
  wait "$java_PID"

  echo "Java process finished. Stopping mpstat..."

  # Gracefully stop mpstat
  kill "$Mpstat_PID"
  wait "$Mpstat_PID" 2>/dev/null  # Ensure it fully stops

  # Extract the average CPU utilization
  utilization=$(awk '/Average/ && $3 != "%usr" {print $3}' "$temp_file")

  # Save the utilization value to cpu3.log
  echo "$utilization" >> cpu3.log

  # Remove the temporary file
  rm "$temp_file"

  # Add the measured utilization to the Excel file
  python3 ../scripts/add_to_excel.py "workbook.xlsx" 13 "$utilization"

  echo "CPU utilization ($utilization%) saved to cpu3.log and workbook.xlsx"
}


update_excel_last_row() {
    local input_file="$1"
    local column_num="$2"
    local new_value="$3"
    local temp_csv="temp.csv"
    local temp_csv_new="temp_new.csv"
    local temp_output_file="temp_output.xlsx"
    local sheet_name="Test_Sheet"

    if ! command -v ssconvert &>/dev/null; then
        echo "Error: ssconvert is not installed. Install it with 'sudo apt-get install gnumeric'."
        return 1
    fi

    if ! command -v libreoffice &>/dev/null; then  # Check for libreoffice
        echo "Error: libreoffice is not installed. Install it (e.g., 'sudo apt-get install libreoffice')."
        return 1
    fi

    # ... (CSV conversion and update logic - same as before) ...

    # Convert back to Excel (using libreoffice for sheet name control)
    libreoffice --headless --convert-to xlsx --outdir . "$temp_csv_new"  # Convert to Excel

    # Rename to the correct output file
    mv "$temp_csv_new.xlsx" "$temp_output_file"

    # Overwrite original file
    mv "$temp_output_file" "$input_file"

    rm -f "$temp_csv" "$temp_csv_new" "$temp_output_file"

    echo "Updated column $column_num in the last row of '$input_file' with value '$new_value', sheet name is '$sheet_name'."
}