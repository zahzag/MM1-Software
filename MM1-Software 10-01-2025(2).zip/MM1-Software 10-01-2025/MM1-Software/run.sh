#!/bin/bash

source scripts/helpers.sh
runs=$1
for ((k=2100000;k>800000;k=k-100000));do
# run the tests $runs time
  configure_cpu_performance 3 $k
  for (( lamda=1 ; lamda<17 ; lamda=lamda+2 )); do

        for ((i = 1 ; i <= $runs; i++)); do
          printf "running server... frequency : $k -> lamda: $lamda -> test : $i  \n"

          cd build
          rm -f cpu3.log
          export CLASSPATH="../Server/Server/lib/*:."
              rm -f core_power.log
              sudo turbostat --cpu 3 --interval 1 --show CorWatt --quiet --Summary -o core_power.log &
              sleep 1s
              TURBOSTAT_PID=$!  # Capture turbostat process ID
              echo "Started measuring CPU core power (PID: $TURBOSTAT_PID) \n"

          java Server.Server $lamda &
          Java_PID=$!

          taskset -c 8 java client.LoadGenerator $lamda 600000 &

          sleep 7s # wait until client start sending requests (7 secondes)

          # Run mpstat in the background, redirecting its output to the temporary file # Create a temporary file to store the output
          mpstat -P 3 1 >> cpu3.log &
          Mpstat_PID=$!

          wait $Java_PID

               # Stop turbostat after Java program finishes
              kill $TURBOSTAT_PID
              sleep 1  # Allow turbostat to finish writing

          kill -SIGINT $Mpstat_PID
          wait "$Mpstat_PID" 2>/dev/null  # Ensure it fully stops

              # Compute total energy consumed by CPU cores
              TOTAL_ENERGY=0
              COUNT=0
              while read PWR; do

                 TOTAL_ENERGY=$(echo "$TOTAL_ENERGY + $PWR" | bc)  # Sum power over time
                 COUNT=$((COUNT + 1))

              done < <(tail -n +2 core_power.log)  # Process file in a subshell

              # Compute total energy in Joules (J)
              TOTAL_ENERGY=$(echo "$TOTAL_ENERGY * 1" | bc)
              AVG_CORE_POWER=$(echo "$TOTAL_ENERGY / $COUNT" | bc -l)
              #add the mesured power to excel file
              python3 ../scripts/add_to_excel.py "workbook.xlsx" 18 $AVG_CORE_POWER
              python3 ../scripts/add_to_excel.py "workbook.xlsx" 19 $TOTAL_ENERGY

          #----------------------------------------------------------------------
          #add the mesured frequency to excel file
          python3 ../scripts/add_to_excel.py "workbook.xlsx" 17 $k
          #----------------------------------------------------------------------
          #add measured utillization cpu3.log

          #utilization=$(awk '/Average/ && $3 != "%usr" {print $3}' "cpu3.log")
          utilization=$(tail -n 5 "cpu3.log" | awk '/Average/ && $3 != "%usr" {print $3; exit}')
          printf "utilization : $utilization \n"
          #add measured utillization to excel file
          python3 ../scripts/add_to_excel.py "workbook.xlsx" 13 "$utilization"
          #----------------------------------------------------------------------
          printf "system sleeping for 5 min \n"
          sleep 3m
        done

         if [[ $lamda -eq 1 ]]; then
                  lamda=0
         fi
  done

done

sudo shutdown now

printf " \n\n "




