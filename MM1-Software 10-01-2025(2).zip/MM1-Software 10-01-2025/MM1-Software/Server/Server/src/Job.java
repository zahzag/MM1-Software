package Server;

import com.sun.management.ThreadMXBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.management.ManagementFactory;

import java.security.NoSuchAlgorithmException;

/** This class represents a job. To each job a time stamp and a repeat value is assigned. The
 * time stamp stands for the arrival of the job at the server. The repeat value is an exponentially
 * distributed integer. This number decides the workload of each job. The calc() implements the processing
 * logic of the job.
 * @author Roohi,Kirschner
 * */

public class Job implements Runnable {
	private static final Logger logger = LoggerFactory.getLogger(Job.class);
	public long timeStamp;
	public int repeat;

	private JobData data = new JobData();
	private long endTimeCurrentRequest;
	private long startTimeStampServiceTime;
	private long endTimeStampServiceTime;
	private long calcTime;
	private long packetLength;
	private long responseTime;
	private long startTimeCpuTime;
	private long endTimeCpuTime;

	private long cpuTime;

	public Job(long timeStamp, int repeat) {
		this.timeStamp = timeStamp;
		this.repeat = repeat;
	}

	// @Override
	public void run() {
		try {
			calc(this.repeat);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		endTimeCurrentRequest = System.nanoTime();
		responseTime = endTimeCurrentRequest - this.timeStamp;//millisecond
		data.setResponseTime(responseTime);
		Server.jobDataQueue.offer(data);

	}

	private void calc(int repeat) throws NoSuchAlgorithmException {
		//		startTimeStampServiceTime = System.nanoTime();

//			for(int k = 0; k < this.repeat; k++) {
//				Math.pow(Math.pow(Math.cbrt(Math.pow(100,20)), Math.cbrt(Math.pow(55,75))), Math.pow( Math.cbrt(Math.pow(55,75)),  Math.cbrt(Math.pow(55,75))));
//				//Math.pow(Math.pow(10,10),Math.pow(10,10));
//			}

		//check the cpu id used to process the job
		int cpuCore = CpuCoreID.CLibrary.INSTANCE.sched_getcpu();
		logger.info("Job CPU Core: " + cpuCore);


		/*******start computing cpu time ************/
		ThreadMXBean threadMXBean = (ThreadMXBean) ManagementFactory.getThreadMXBean();
		if (threadMXBean.isThreadCpuTimeSupported() && threadMXBean.isThreadCpuTimeEnabled()) {

		//computing execution time
		startTimeStampServiceTime = System.nanoTime();

			// Start cpuTime in nanoseconds
			 startTimeCpuTime = threadMXBean.getCurrentThreadCpuTime();

				System.out.println("repeat :"+ repeat);
				// Perform the job
				double result =0.0;
				for (double i = 0; i < this.repeat; i++) {
					result += 1 / Math.pow(i, 2);
				}
//			for(int k = 0; k < this.repeat; k++) {
//				Math.pow(Math.pow(Math.cbrt(40), Math.cbrt(20)), Math.pow(Math.cbrt(40), Math.cbrt(20)));
//			}


			// Get end CPU time
			endTimeCpuTime = threadMXBean.getCurrentThreadCpuTime(); // In nanoseconds

		//end computing execution time
		endTimeStampServiceTime = System.nanoTime();


		} else {
			System.out.println("Thread CPU time measurement is not supported on this JVM.");
		}

		/*******stop computing cpu time ************/

		//execution time
		calcTime = (endTimeStampServiceTime - startTimeStampServiceTime); //nanoseconds
		System.out.println("executionTime : " +calcTime/1_000_000.0 + " ms");

		// Calculate and display CPU time
		cpuTime = endTimeCpuTime - startTimeCpuTime;
		System.out.println("CPU Time for Job: " + cpuTime /1_000_000.0 + " ms");

		data.setCalcTime(calcTime);
		data.setCpuTime(cpuTime);
		packetLength = repeat;
		data.setPacketLength(packetLength);

	}

}


